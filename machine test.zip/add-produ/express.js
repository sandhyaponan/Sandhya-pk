const express = require('express')
const bodyParser = require('body-parser')
const app = express()

app.use(bodyParser.urlencoded({limit: '200mb', extended: true}))

// parse application/json
app.use(bodyParser.json({limit: '200mb'}))
app.use(bodyParser.text({ limit: '200mb' }));


module.exports = app