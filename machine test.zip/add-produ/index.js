const app = require('./express');
const dotenv = require('dotenv')
const fs = require("fs");
const {
    v1: uuidv1,
    v4: uuidv4,
} = require('uuid');
dotenv.config()

console.log(process.env)

app.set("view engine", "jade")

// app.get('/', function (req, res) {

//     res.render('sample');

// });

app.get('/', (req, res) => {
    res.sendFile('index.html', {
        root: './'
    });
});

app.post('/add-product', function (req, res) {
    const request = {
        id: uuidv4(),
        name: req.body.name,
        description: req.body.description,
        mrp: req.body.mrp,
        shipping: req.body.shipping,
        discount: req.body.discount,
    }
    fs.readFile("products.json", function (err, buf) {
        const json = JSON.parse(buf);
        const newJSON = [...json, request];
        fs.writeFile("products.json", JSON.stringify(newJSON), (err) => {
            if (err) console.log(err);
            console.log("Successfully Written to File.");
            res.send(true)
        });
    });
})

app.post('/update-product', function (req, res) {

    fs.readFile("products.json", function (err, buf) {
        const json = JSON.parse(buf);
        let index = json.findIndex(jsn => jsn.id === req.body.id)
        json[index].name = req.body.name;
        json[index].description = req.body.description;
        json[index].mrp = req.body.mrp;
        json[index].shipping = req.body.shipping;
        json[index].discount = req.body.discount;
        const newJSON = [...json];
        fs.writeFile("products.json", JSON.stringify(newJSON), (err) => {
            if (err) console.log(err);
            console.log("Successfully Written to File.");
            res.send(true)
        });
    });
})

app.post('/delete-product', function (req, res) {

    fs.readFile("products.json", function (err, buf) {
        const json = JSON.parse(buf);
        let index = json.findIndex(jsn => jsn.id === req.body.id)
        json.splice(index,1)
        const newJSON = [...json];
        fs.writeFile("products.json", JSON.stringify(newJSON), (err) => {
            if (err) console.log(err);
            console.log("Successfully Written to File.");
            res.send(true)
        });
    });
})

const PORT = process.env.PORT || 3200;

app.listen(PORT, () => {
    console.log(`App listening at http://localhost:${PORT}`)
})